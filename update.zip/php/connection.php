<?php
$host = 'LAPTOP-1BD60QI6\SQLEXPRESS';
$dbname = 'registration_db';

try {
    // Omit the Authentication keyword for Windows Authentication (Integrated Security)
    $con = new PDO("sqlsrv:Server=$host;Database=$dbname");
    $con->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    echo "Connected successfully!";
    $con = null;
} catch (PDOException $e) {
    die("Connection failed: " . $e->getMessage());
}
?>
