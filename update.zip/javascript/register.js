function showPassword() {
    const passwordInput = document.getElementById("password");
    if (passwordInput.type === "password") {
        passwordInput.type = "text";
    } else {
        passwordInput.type = "password";
    }
}

function showEmail() {
    const emailInput = document.getElementById("email");
    if (emailInput.type === "email") {
        emailInput.type = "text";
    } else {
        emailInput.type = "email";
    }
}

const passwordInput = document.getElementById("password");
passwordInput.addEventListener("input", checkPassword);

function checkPassword() {
    const password = passwordInput.value;
    const passwordError = document.getElementById("password-error");
    const passwordPattern = /^(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,}$/;

    if (!password.match(passwordPattern)) {
        passwordError.textContent = "Password must contain at least 8 characters, including at least one digit, one lowercase, and one uppercase letter.";
    } else {
        passwordError.textContent = "";
    }
}

const emailInput = document.getElementById("email");
emailInput.addEventListener("input", checkEmail);

function checkEmail() {
    const email = emailInput.value;
    const emailError = document.getElementById("email-error");
    const emailPattern = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;

    if (!email.match(emailPattern)) {
        emailError.textContent = "Invalid email address.";
    } else {
        emailError.textContent = "";
    }
}