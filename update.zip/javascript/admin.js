$(document).ready(function() {
    // Toggle sidebar on small screens
    $('.navbar-toggler').on('click', function() {
        $('.sidebar').toggleClass('active');
    });
});