<!DOCTYPE html>
<html>
<head>
    <title>Registration Status</title>
    <link rel="stylesheet" href="../bootstrap/css/bootstrap.min.css">
</head>
<body>
<?php
if (isset($_GET['status'])):
    if ($_GET['status'] === "success"):
?>
        <div class="alert alert-success mt-3" role="alert">
            Registration successful! You can now log in.
        </div>
<?php
    elseif ($_GET['status'] === "error"):
?>
        <div class="alert alert-danger mt-3" role="alert">
            Error: Registration failed. Please try again later.
        </div>
<?php
    elseif ($_GET['status'] === "validation_failed"):
?>
        <div class="alert alert-warning mt-3" role="alert">
            All fields are required. Please fill in all the required fields.
        </div>
<?php
    endif;
endif;
?>

    </div>
</body>
</html>