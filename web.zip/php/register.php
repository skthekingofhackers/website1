<?php
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    // Retrieve form data
    $first_name = $_POST["first_name"];
    $middle_name = $_POST["middle_name"];
    $last_name = $_POST["last_name"];
    $address = $_POST["address"];
    $pincode = $_POST["pincode"];
    $state = $_POST["state"];
    $mobile_number = $_POST["mobile_number"];
    $username = $_POST["username"];
    $password = $_POST["password"];
    $email = $_POST["email"];

    // Server-side validation and further processing
    // Add your validation and database logic here

    // If registration is successful, redirect to a success page
    header("Location: registration_success.php");
    exit;
}
?>
