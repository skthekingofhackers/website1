<?php
// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    // Validate and sanitize the input data
    $first_name = htmlspecialchars(trim($_POST["first_name"]));
    $middle_name = htmlspecialchars(trim($_POST["middle_name"]));
    $last_name = htmlspecialchars(trim($_POST["last_name"]));
    $address = htmlspecialchars(trim($_POST["address"]));
    $pincode = htmlspecialchars(trim($_POST["pincode"]));
    $state = htmlspecialchars(trim($_POST["state"]));
    $mobile_number = htmlspecialchars(trim($_POST["mobile_number"]));
    $otp = htmlspecialchars(trim($_POST["otp"]));
    $username = htmlspecialchars(trim($_POST["username"]));
    $password = password_hash($_POST["password"], PASSWORD_DEFAULT); // Hash the password
    $email = htmlspecialchars(trim($_POST["email"]));

    // Perform server-side validation (You can add more validation rules as needed)
    if (empty($first_name) || empty($last_name) || empty($address) || empty($pincode) || empty($state) || empty($mobile_number) || empty($otp) || empty($username) || empty($password) || empty($email)) {
        $registrationStatus = "validation_failed";
    } else {
        // Save the data in the database using PDO
        try {
            // Replace 'database_name', 'username', and 'password' with your actual database credentials
            $db = new PDO("mysql:host=localhost;dbname=website_db", "admin", "admin");
            $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

            // Prepare the SQL query and bind parameters to prevent SQL injection
            $stmt = $db->prepare("INSERT INTO registered_users (first_name, middle_name, last_name, address, pincode, state, mobile_number, otp, username, password, email) VALUES (:first_name, :middle_name, :last_name, :address, :pincode, :state, :mobile_number, :otp, :username, :password, :email)");
            $stmt->bindParam(":first_name", $first_name);
            $stmt->bindParam(":middle_name", $middle_name);
            $stmt->bindParam(":last_name", $last_name);
            $stmt->bindParam(":address", $address);
            $stmt->bindParam(":pincode", $pincode);
            $stmt->bindParam(":state", $state);
            $stmt->bindParam(":mobile_number", $mobile_number);
            $stmt->bindParam(":otp", $otp);
            $stmt->bindParam(":username", $username);
            $stmt->bindParam(":password", $password);
            $stmt->bindParam(":email", $email);

            // Execute the query
            $stmt->execute();

            // Registration successful
            $registrationStatus = "success";
        } catch (PDOException $e) {
            // Handle database errors
            $registrationStatus = "error";
        } finally {
            // Close the database connection
            $db = null;
        }
    }
}
// Redirect back to the registration page with the registration status as a query parameter
header("Location: ../php/status.php?status=" . urlencode($registrationStatus));
exit;
?>